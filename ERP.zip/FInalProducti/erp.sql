-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 30, 2018 at 02:01 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 7.1.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `erp`
--

-- --------------------------------------------------------

--
-- Table structure for table `course`
--

CREATE TABLE `course` (
  `CID` int(10) NOT NULL,
  `COURSE` varchar(20) NOT NULL,
  `DURATION` int(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `department`
--

CREATE TABLE `department` (
  `DID` int(10) NOT NULL,
  `DNAME` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `department`
--

INSERT INTO `department` (`DID`, `DNAME`) VALUES
(1, 'CE'),
(2, 'CSE'),
(3, 'ELE'),
(4, 'ME'),
(5, 'ELECTRONICS'),
(6, 'IT');

-- --------------------------------------------------------

--
-- Table structure for table `registeruser`
--

CREATE TABLE `registeruser` (
  `NAME` varchar(25) NOT NULL,
  `PASS` varchar(25) NOT NULL,
  `EMAIL` varchar(25) NOT NULL,
  `COUNTRY` varchar(50) NOT NULL,
  `UID` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `registeruser`
--

INSERT INTO `registeruser` (`NAME`, `PASS`, `EMAIL`, `COUNTRY`, `UID`) VALUES
('', '', '', '', 1),
('vineet', '123', 'vineetkumarmour', 'India', 2);

-- --------------------------------------------------------

--
-- Table structure for table `studentform`
--

CREATE TABLE `studentform` (
  `sid` int(10) NOT NULL,
  `NAME` varchar(50) NOT NULL,
  `DOB` date NOT NULL,
  `FATHER` varchar(50) NOT NULL,
  `MOTHER` varchar(50) NOT NULL,
  `SEX` varchar(50) NOT NULL,
  `COURSENAME` varchar(50) NOT NULL,
  `BRANCH` varchar(50) NOT NULL,
  `YEAR` varchar(50) NOT NULL,
  `MOBILE` varchar(50) NOT NULL,
  `FMOBILE` varchar(50) NOT NULL,
  `ADDRESS` varchar(150) NOT NULL,
  `BANKNAME` varchar(50) NOT NULL,
  `BBRANCH` varchar(50) NOT NULL,
  `IFSCCODE` varchar(50) NOT NULL,
  `ACCOUNTNO` varchar(50) NOT NULL,
  `PASSWORD` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `studentform`
--

INSERT INTO `studentform` (`sid`, `NAME`, `DOB`, `FATHER`, `MOTHER`, `SEX`, `COURSENAME`, `BRANCH`, `YEAR`, `MOBILE`, `FMOBILE`, `ADDRESS`, `BANKNAME`, `BBRANCH`, `IFSCCODE`, `ACCOUNTNO`, `PASSWORD`) VALUES
(178121, 'VINEET KUMAR ', '1998-07-01', 'LAL BAHADUR', 'MUNNI DEVI ', 'MALE', 'BTECH', 'CSE', 'III', '8171842600', '9917725696', 'MOH MALIPURA MEERGANJ BAREILLY', 'PUNJABNATION BANK ', 'KNIT SULTANPUR', 'PUNB0638400', '638400010006575', '123'),
(178122, 'VINEET KUMAR ', '1998-07-01', 'LAL BAHADUR', 'MUNNI DEVI ', 'MALE', 'BTECH', 'CSE', 'III', '8171842600', '9917725696', 'MOH MALIPURA MEERGANJ BAREILLY', 'PUNJABNATION BANK ', 'KNIT SULTANPUR', 'PUNB0638400', '638400010006575', '123'),
(178123, 'VINEET KUMAR ', '1998-07-01', 'LAL BAHADUR', 'MUNNI DEVI ', 'MALE', 'BTECH', 'CSE', 'III', '8171842600', '9917725696', 'MOH MALIPURA MEERGANJ BAREILLY', 'PUNJABNATION BANK ', 'KNIT SULTANPUR', 'PUNB0638400', '638400010006575', '123'),
(178124, 'VINEET KUMAR ', '1998-07-01', 'LAL BAHADUR', 'MUNNI DEVI ', 'MALE', 'BTECH', 'CSE', 'III', '8171842600', '9917725696', 'MOH MALIPURA MEERGANJ BAREILLY', 'PUNJABNATION BANK ', 'KNIT SULTANPUR', 'PUNB0638400', '638400010006575', '123'),
(178125, 'KIRAN', '1996-09-08', 'PRAM  YADA', 'NANHI', 'FEMALE', 'null', 'CSE', 'iii', '8650903882', '8171842600', 'RAMPUR UP', 'PNB', 'MEERGANJ', 'PUNB0638400', '63840001000515', '123456'),
(178126, 'PRASHANT', '1999-10-01', 'KDJFKJKDJ', 'LKDJFKJL', 'AMEL', 'null', 'CSE', 'iv', '9005829535', '8171842600', 'Bareilly', 'punjab', 'MEERGANJ', 'eee', 'eee', '123456789');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `UID` int(10) NOT NULL,
  `UNAME` varchar(15) NOT NULL,
  `password` varchar(25) NOT NULL,
  `mobile` varchar(13) NOT NULL,
  `DOB` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`UID`, `UNAME`, `password`, `mobile`, `DOB`) VALUES
(1, 'on', '1234', '0', '0000-00-00'),
(2, 'admin', 'admin', '0', '0000-00-00'),
(178212, 'vineet', '178212', '0', '0000-00-00'),
(178215, 'VINEET1', '123', '8171842600', '0000-00-00'),
(178216, 'VINEET2', '123', '8171842600', '2018-11-07'),
(178217, 'eee22', 'eeee', '8171842600', '2018-11-23'),
(178219, 'knit', '123456', '8171842600', '1998-07-12'),
(178220, 'knit2', '123456789', '8171842600', '1998-07-12'),
(178221, 'PRASHANT', '123456789', '8171842600', '1998-07-12'),
(178222, 'ghulam', '123456789', '8171842600', '1998-07-02'),
(178223, 'diwakar', '123456789', '8171842600', '1998-07-12'),
(178226, 'diwakar j', 'diwakar', '8650903882', '1995-04-25');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `course`
--
ALTER TABLE `course`
  ADD UNIQUE KEY `CID` (`CID`);

--
-- Indexes for table `department`
--
ALTER TABLE `department`
  ADD UNIQUE KEY `DID` (`DID`);

--
-- Indexes for table `registeruser`
--
ALTER TABLE `registeruser`
  ADD PRIMARY KEY (`UID`);

--
-- Indexes for table `studentform`
--
ALTER TABLE `studentform`
  ADD PRIMARY KEY (`sid`),
  ADD UNIQUE KEY `sid` (`sid`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`UID`),
  ADD UNIQUE KEY `UNAME` (`UNAME`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `department`
--
ALTER TABLE `department`
  MODIFY `DID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `registeruser`
--
ALTER TABLE `registeruser`
  MODIFY `UID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `studentform`
--
ALTER TABLE `studentform`
  MODIFY `sid` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=178127;
--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `UID` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=178227;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
