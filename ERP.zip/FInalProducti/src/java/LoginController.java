import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LoginController
 */
public class LoginController extends HttpServlet {
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String un=request.getParameter("username");
		String pw=request.getParameter("password");
		
		// Connect to mysql and verify username password
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
		 // loads driver
		Connection c = DriverManager.getConnection("jdbc:mysql://localhost:3306/erp", "root", ""); // gets a new connection
                //SELECT `UID`, `UNAME`, `password` FROM `user` WHERE uid = 2 and password = 'admin'
		PreparedStatement ps = c.prepareStatement("SELECT `UID`, `UNAME`, `password` FROM `user` WHERE uid = ? and password =?");
		ps.setString(1, un);
		ps.setString(2, pw);
 
		ResultSet rs = ps.executeQuery();
 
		while (rs.next()) {
                        HttpSession session= request.getSession();
                        session.setAttribute("username", un);
                        if(session.getAttribute("username")==null){
                           response.sendRedirect("index.html");
                        }
			response.sendRedirect("Adminpage.html");
			return;
		}
		response.sendRedirect("index.html");
		return;
		} catch (ClassNotFoundException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}